import java.util.ArrayList;
import java.util.Scanner;

class Student {
    String id;
    String name;
    int age;
    String email;
    String course;

    // Constructor to initialize the student details
    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    @Override
    public String toString() {
        return "STUDENT ID: " + id + "\nSTUDENT NAME: " + name + "\nSTUDENT AGE: " + age +
                "\nSTUDENT EMAIL: " + email + "\nSTUDENT COURSE: " + course;
    }
}

public class Main {
    static Scanner scanner = new Scanner(System.in);
    static ArrayList<Student> students = new ArrayList<>();  // To store the list of students

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n*******");
            System.out.println("STUDENT MANAGEMENT APPLICATION");
            System.out.println("Enter (1) to launch menu or any other key to exit");
            String choice = scanner.nextLine();
            if (!choice.equals("1")) {
                break;
            }
            showMenu();  // Displays the menu
        }
    }

    // Displays the menu and handles user choices
    public static void showMenu() {
        System.out.println("\nPlease select one of the following menu items:");
        System.out.println("(1) Capture a new student.");
        System.out.println("(2) Search for a student.");
        System.out.println("(3) Delete a student.");
        System.out.println("(4) Print student report.");
        System.out.println("(5) Exit Application.");

        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                captureStudent();  // Capture new student details
                break;
            case "2":
                searchStudent();  // Search for a student by ID
                break;
            case "3":
                deleteStudent();  // Delete a student by ID
                break;
            case "4":
                printReport();  // Print all student details
                break;
            case "5":
                System.exit(0);  // Exit the application
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    // Capture new student details
    public static void captureStudent() {
        System.out.println("\nCAPTURE A NEW STUDENT");

        System.out.print("Enter the student id: ");
        String id = scanner.nextLine();

        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

        int age = 0;
        while (age < 16) {
            System.out.print("Enter the student age (must be 16 or older): ");
            age = Integer.parseInt(scanner.nextLine());
            if (age < 16) {
                System.out.println("You have entered an incorrect student age!!!");
            }
        }

        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        students.add(new Student(id, name, age, email, course));  // Add the new student to the list
        System.out.println("Student details have been successfully saved.");
    }

    // Search for a student by their ID
    public static void searchStudent() {
        System.out.print("\nEnter the student id to search: ");
        String id = scanner.nextLine();

        for (Student student : students) {
            if (student.id.equals(id)) {
                System.out.println(student);
                return;
            }
        }
        System.out.println("Student with ID: " + id + " was not found.");
    }

    // Delete a student by their ID
    public static void deleteStudent() {
        System.out.print("\nEnter the student id to delete: ");
        String id = scanner.nextLine();

        for (Student student : students) {
            if (student.id.equals(id)) {
                students.remove(student);
                System.out.println("Student with ID: " + id + " has been deleted.");
                return;
            }
        }
        System.out.println("Student with ID: " + id + " was not found.");
    }

    // Print all student details
    public static void printReport() {
        if (students.isEmpty()) {
            System.out.println("No students to display.");
            return;
        }

        System.out.println("\nSTUDENT REPORT");
        for (Student student : students) {
            System.out.println(student);
            System.out.println("----------------------");
        }
    }
}