import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

public class StudentTest {

    @BeforeEach
    void setUp() {
        // Clear the student list before each test
        Main.students = new ArrayList<>();
    }

    // Test saving a student
    @Test
    public void testSaveStudent() {
        // Call the method to save a new student
        Student student = new Student("ST10436950", "Hawa Habonimana", 23, "habonimanaexample.com", "Information tech");
        Main.students.add(student);

        // Assert that the student was saved
        assertEquals(1, Main.students.size());
        assertEquals("ST10436950", Main.students.get(0).id);
    }

    // Test searching a student that exists
    @Test
    public void testSearchStudent() {
        // Add a student to the list
        Student student = new Student("ST10436950", "Hawa Habonimana", 23, "habonimanaexample.com", "Information tech");
        Main.students.add(student);

        // Search for the student
        Student result = searchById("ST10436950");

        // Assert the student is found and has correct details
        assertNotNull(result);
        assertEquals("Hawa Habonimana", result.name);
        assertEquals("ST10436950", result.id);
    }

    // Test searching for a student that does not exist
    @Test
    public void testSearchStudent_StudentNotFound() {
        // Search for a student that doesn't exist
        Student result = searchById("ST10101010");

        // Assert that no student was found
        assertNull(result);
    }

    // Test deleting a student that exists
    @Test
    public void testDeleteStudent() {
        // Add a student to the list
        Student student = new Student("ST10436950", "Hawa Habonimana", 23, "habonimanaexample.com", "Information tech");
        Main.students.add(student);

        // Delete the student
        boolean isDeleted = deleteById("ST10436950");

        // Assert the student was deleted
        assertTrue(isDeleted);
        assertEquals(0, Main.students.size());
    }

    // Test deleting a student that does not exist
    @Test
    public void testDeleteStudent_StudentNotFound() {
        // Try to delete a student that doesn't exist
        boolean isDeleted = deleteById("ST10101010");

        // Assert the student was not found and not deleted
        assertFalse(isDeleted);
        assertEquals(0, Main.students.size());
    }

    // Test student age validation with valid age
    @Test
    public void testStudentAge_StudentAgeValid() {
        // Call the age validation method with valid age
        int age = 18;
        assertTrue(isAgeValid(age));
    }

    // Test student age validation with age less than 16
    @Test
    public void testStudentAge_StudentAgeInvalid() {
        // Call the age validation method with invalid age
        int age = 15;
        assertFalse(isAgeValid(age));
    }

    // Test student age validation with non-numeric character
    @Test
    public void testStudentAge_StudentAgeInvalidCharacter() {
        // Test for exception when invalid character is supplied as age
        assertThrows(NumberFormatException.class, () -> {
            int age = Integer.parseInt("abc");
            isAgeValid(age);
        });
    }

    // Helper method to search student by ID
    private Student searchById(String id) {
        for (Student student : Main.students) {
            if (student.id.equals(id)) {
                return student;
            }
        }
        return null;
    }

    // Helper method to delete student by ID
    private boolean deleteById(String id) {
        for (Student student : Main.students) {
            if (student.id.equals(id)) {
                Main.students.remove(student);
                return true;
            }
        }
        return false;
    }

    // Helper method to validate student age
    private boolean isAgeValid(int age) {
        return age >= 16;
    }
}